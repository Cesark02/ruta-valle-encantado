FONTLOG for Bronova
Copyright 2020 DesignBro Ltd (https://designbro.com)

A free display font created by DesignBro.
Website: https://designbro.com


Bronova is a sans-serif font project by the DesignBro.com team. 

--------------

On launch a regular and bold font were included, as well as the required 215 glyphs for both variants.

--------------

